# Tsunami documentation

- [How tsunami works]({{ site.baseurl }}/howto/orchestration)
- Guides
  * [How to build and run Tsumami]({{ site.baseurl }}/howto/howto)
  * [How to write a detector]({{ site.baseurl }}/howto/new-detector)
  * [Common detector patterns]({{ site.baseurl }}/howto/common-patterns)
  (i.e. "How do I do that?!")
